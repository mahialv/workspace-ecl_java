/**
 * Created by kalpriya on 6/9/2016.
 */
function sendRequest(){
    var XHR = getXHR()
    if(XHR){
        XHR.open("GET","data/data.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
}

function handleResponse(XHR){
   // console.log("data received... ",XHR.state);
    if(XHR.readyState==4){
       // console.log("data received... ",XHR.responseText);
        var persons = JSON.parse(XHR.responseText);
        var table = document.getElementById('list');
        var fname=document.getElementById('fname').value;
        var lname=document.getElementById('lname').value;
        var state=document.getElementById('state').value;
        var city=document.getElementById('city').value;
      //  console.log(persons);
        for(var i=0;i<=persons.length;i++){
           if(fname != "" && lname!=""){
                  persons[i].firstname=fname;
                  persons[i].lastname=lname;
                  persons[i].state=state;
                  persons[i].city=city;
           }
        }

        for(var i=0;i<persons.length;i++){
            var row =table.insertRow(i);
            var cell1 = row.insertCell(0);
            cell1.innerHTML = "<button type='button' onclick='updateTextArea("+persons[i]+")'>"+persons[i].lastname+" "+persons[i].firstname+"</button><br>";
        }

    }
}
function updateTextArea(person){
    console.log(person.firstname,person.lastname);
    document.getElementById('fname').innerHTML=person.firstname;
    document.getElementById('lname').innerHTML=person.lastname;
    document.getElementById('state').innerHTML=person.state;
    document.getElementById('city').innerHTML=person.city;
}