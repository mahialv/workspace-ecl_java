/**
 * Created by alareddy on 09-Jun-16.
 */
function sendRequest(){
    var XHR = getXHR();
    if(XHR){
        XHR.open("GET","data/data.json",true);
        XHR.onreadystatechange = function(){handleResponse(XHR);}
        XHR.send();
    }
}

function getXHR(){
    return new XMLHttpRequest();
}

function handleResponse(XHR){
    if(XHR.readyState==4){


        var sideBar= document.getElementById('addData');
        persons = JSON.parse(XHR.responseText);

        for(var i=0;i<persons.length;i++) {

            var table = document.getElementById("addData");
            var row = table.insertRow(i);
            var cell1 = row.insertCell(0);
            //  cell1.innerHTML = "<button type='button' class='btn btn-default' onclick='"+getDetails(this)+"' value='"+ persons[i].firstName + ", "+persons[i].lastName  +"'> </button>";


            cell1.innerHTML="<button type='button' class='btn btn-default btn-block' onclick='getDetail(this)' id="+i+">"+persons[i].lastName+" "+persons[i].firstName+"</button>";

            // var btn = document.createElement("BUTTON");
            // btn.className = "btn btn-default btn-block";
            //
            // var t = document.createTextNode(persons[i].firstName + ', '+persons[i].lastName);
            //  btn.onclick =getDetails(this);
            // btn.appendChild(t);

            //

            //sideBar.appendChild(btn);
            //
            //  cell1.appendChild(btn);

            // sideBar.innerHTML = "<li> <input type=\"button\" value=\""+  persons[i].firstName + ", "+persons[i].lastName+ "\"></li>";
            //  sideBar.innerHTML = "<li> <button >"+  persons[i].firstName + ", "+persons[i].lastName+ "</button></li>";
        }
    }
}
//
// function getDetails(index) {
//     console.log(persons[0].firstName);
//     document.getElementById('firstName').value = persons[index.id].firstName;
//     document.getElementById('lastName').value = persons[index].lastName;
//     document.getElementById('state').value = persons[index].state;
//     document.getElementById('city').value = persons[index].city;
//
// }

function getDetail(btn){
    document.getElementById('firstName').value=persons[btn.id].firstName;

    document.getElementById('lastName').value =persons[btn.id].lastName;

    document.getElementById('state').value =persons[btn.id].city;

    document.getElementById('city').value =persons[btn.id].state;

}


function save() {

}
/**
 * Created by alareddy on 6/10/2016.
 */
