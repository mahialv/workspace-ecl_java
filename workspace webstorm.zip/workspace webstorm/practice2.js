/**
 * Created by alareddy on 6/8/2016.
 */


var a = b();
 var c = d();

console.log(a);
console.log(c);

function b(){
    return c;

}
function d(){
    return c;

}