package com.student.studentproject;

import java.util.Scanner;

public class UserInterface
{
	private static Scanner sc=new Scanner(System.in);
	private static StudentScheduler studSch=new StudentScheduler();
	public static void main(String[] args) {
		showMenu();
	}

	private static void showMenu() {
		int choice;
		
		while(true)
		{
			System.out.println("1.add student");
			System.out.println("2.show all students");
			System.out.println("3.show by roll number");
			System.out.println("4.exit");
			
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			
			switch(choice)
			{
				case 1:acceptStudentDetails();
					   break;
				case 2:showAllStudentDetails();
					   break;
				case 3:System.out.println("\n Enter the roll number: ");
					   int rollNumber=sc.nextInt();
					   showByRollNumber(rollNumber);
					   break;
				case 4:System.exit(0);
			}
		}
		
	}

		
	private static void acceptStudentDetails() {
		System.out.println("Enter roll number");
		int rollNumber=sc.nextInt();
		System.out.println("Enter name");
		String name=sc.next();
		
		System.out.println("\n Enter the number of courses: ");
		int countCourses = sc.nextInt();
		
		String[] courseNames = new String[countCourses];
		
		System.out.println("\n Enter the course names: ");
		for(int i=0;i<countCourses;i++){
			courseNames[i] = sc.next();
		}
		
		System.out.println(studSch.addStudent(rollNumber, name, courseNames));
		
	}

	private static void showAllStudentDetails(){
		studSch.showAllStudents();
		
	}

	private static void showByRollNumber(int rollNumber) {
		studSch.displayByRollNumber(rollNumber);
	}


}

