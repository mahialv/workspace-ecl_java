package com.student.studentproject;

public class StudentScheduler 
{
	private Student[] students=new Student[10];
	private int counterStudent;
	
	public String addStudent(int rollNumber,String name, String[] courseName)
	{
		for(int i=0; i<counterStudent; i++){
			if(students[i].getRollNumber() == rollNumber){
				return "Duplicate Roll number! Could not add student";
			}
		}
		students[counterStudent++]=new Student(rollNumber,name, courseName);
		return "Student added successfully";
	}

	public void showAllStudents()
	{
		for(int i=0; i<counterStudent; i++)
		{
			System.out.println();
			System.out.println("Roll number: "+students[i].getRollNumber());
			System.out.println("Name: "+students[i].getName());
			System.out.println("Courses: ");
			
			for(int j=0; j<students[i].getCourseName().length;j++){
				System.out.println("\n  "+students[i].getCourseName()[j]);
			}
			System.out.println();
		}
		
	}

	public void displayByRollNumber(int rollNumber) {
				
		for(int i=0;i<counterStudent;i++){
			if(rollNumber == students[i].getRollNumber()){
				
				System.out.println("\nRoll number found!");
				System.out.println("Name: "+students[i].getName());
				for(int j=0;j<students[i].getCourseName().length;j++){
					System.out.println();
					System.out.println(students[i].getCourseName()[j]);
					
				}
			}
			else{
				System.out.println("\n Roll number not found!");
			}
		}
	}
}

