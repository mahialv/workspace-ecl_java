package com.quiz;

	public class TestClass
	{
		public void testRefs(String str, StringBuffer sb)
		{
			str = str + sb.toString();
			sb.append(str);
			str = null;
			sb = null;
		}
		public static void main(String[] args)
		{
			String s = "aaa";
			StringBuffer sb = new StringBuffer("bbb");
			new TestClass().testRefs(s, sb);
			System.out.println("s="+s+" sb="+sb);
		}
	}


