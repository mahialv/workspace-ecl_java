package com.baking;


public class InvalidAccountNumberException extends Exception {

}