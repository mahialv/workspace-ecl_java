package com.baking;


public class Client {

	public static void main(String[] args) {
		ICICIBank bank=new ICICIBank();
		
		System.out.println(bank.createAccount(101, 1000));
		
		System.out.println(bank.createAccount(102, 3000));
		
		System.out.println(bank.createAccount(108, 5000));
		
		System.out.println(bank.createAccount(110, 300));
		
		try
		{
			int [] arr  = bank.fundTransfer(108,101,2000);
			System.out.println(arr[0]+"   "+ arr[1]);
		}
		catch(InvalidAccountNumberException ian)
		{
			System.out.println("Invalid account number");
		}catch(InsufficientBalanceException ibe)
		{
			System.out.println("insufficient balance");
		}
			
			try{
				System.out.println(bank.depositAmount(110,2000));
			}
			catch(InvalidAccountNumberException ian)
			{
				System.out.println("Invalid account number");
			}
			
			try{
				
			
			System.out.println("Balance = "+bank.withdrawAmount(1001, 2000));
			
		}catch(InvalidAccountNumberException ian)
		{
			System.out.println("Invalid account number");
		}catch(InsufficientBalanceException ibe)
		{
			System.out.println("insufficient balance");
		}

	}

}
