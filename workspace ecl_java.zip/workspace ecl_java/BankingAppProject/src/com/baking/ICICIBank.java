package com.baking;

import java.util.LinkedList;

public class ICICIBank {
	
	LinkedList<Account> accounts=new LinkedList<Account>();
	
	
	public String createAccount(int accountNumber,int amount)
	{
		Account account=new Account(accountNumber,amount);
		if(amount<500){
            return "amount should be above 500";
		}
		accounts.add(account);
		
		return "account created successfully";
	}
	
	private Account searchAccount(int accountNumber)throws InvalidAccountNumberException
	{
		for(Account account:accounts)
		{
			if(account.getAccountNumber()==accountNumber)
			{
				return account;
			}
			
		}
		throw new InvalidAccountNumberException();
		
	}
	
	public int withdrawAmount(int accountNumber,int amount)throws InsufficientBalanceException, InvalidAccountNumberException
	{
		Account account = searchAccount(accountNumber);
		
		if((account.getAmount()-amount)>=0)
		{
			account.setAmount(account.getAmount()-amount);
			return account.getAmount();
		}
		
		throw new InsufficientBalanceException();
	}
   public int depositAmount(int accountNumber, int amount)throws InvalidAccountNumberException
{
	   Account account = new Account(accountNumber,amount);
	   for(Account account1:accounts){

	   if(account1.getAccountNumber()==accountNumber)
	   {
		   account1.setAmount(account1.getAmount()+amount);
		   return account1.getAmount();
	   }
	   }
	   throw new InvalidAccountNumberException();
}

   public int[] fundTransfer(int fromAccountNumber, int toAccountNumber, int amount)throws InsufficientBalanceException,InvalidAccountNumberException{
	   Account account1 = searchAccount(fromAccountNumber);
	   Account account2 = searchAccount(toAccountNumber);
  if(account1.getAmount()>amount)
  {
	  account2.setAmount(account2.getAmount()+amount);
	  account1.setAmount(account1.getAmount()-amount);
  int [] arr = {account1.getAmount(), account2.getAmount()};
  return arr;
  
  }
  throw new InsufficientBalanceException();
   
}
   
   
   
   
}
