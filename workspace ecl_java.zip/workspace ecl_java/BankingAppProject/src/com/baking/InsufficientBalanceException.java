package com.baking;

public class InsufficientBalanceException extends Exception {

}
