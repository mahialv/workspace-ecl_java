package practice;

public class Test1 {

	public static void main(String[] args) {
	 Employee e= new Employee();
	 e.setAge(20);
	 System.out.println(e.getAge());
	 

	}

}
