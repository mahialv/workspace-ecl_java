package practice;

public class DefaultValue {
	 byte b;
     short s;
int i;
long l;
float f;
double d;
boolean boo;
char ch;

	public static void main(String[] args) {
		DefaultValue df = new DefaultValue();
		System.out.println(df.b);
		System.out.println(df.s);
		System.out.println(df.i);
		System.out.println(df.l);
		System.out.println(df.f);
		System.out.println(df.d);
		System.out.println(df.boo);
		System.out.println(df.ch);
		
		

	}

}
