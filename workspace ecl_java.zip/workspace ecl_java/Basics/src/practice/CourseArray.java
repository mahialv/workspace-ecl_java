package practice;
import java.util.Scanner;
 

public class CourseArray {

	private static Scanner sc;

	public static void main(String[] args) {
		sc = new Scanner(System.in);
     int courses = 0;
     String rollno;
     
     System.out.println("\n enter your roll number");
     rollno = sc.next();
     System.out.println("\n enter the number of courses");
     courses = sc.nextInt();
     
     String[] coursearray = new String[courses];
     System.out.println("\n enter the name of courses:");
      for(int i=0; i<coursearray.length;i++)
      {
    	  coursearray[i] = sc.next();
      }
      System.out.println();
      System.out.println("roll number:"+ rollno +" has these couses:"+ courses);
      
     for(int i=0; i<coursearray.length; i++)
     {
    	 System.out.println(coursearray[i]);
     }
     
     		
     
	}

}
