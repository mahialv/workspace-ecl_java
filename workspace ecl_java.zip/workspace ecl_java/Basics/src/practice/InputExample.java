package practice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class InputExample {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter two numbers");
			
			String first = br.readLine();
			String second = br.readLine();
			
			int num1 = Integer.parseInt(first);
			int num2 = Integer.parseInt(second);
			
			System.out.println("addition ="+(num1+num2));
			
		

	}

}
