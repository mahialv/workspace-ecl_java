package practice;

public class Test {
	
	int a;
	Test(int a)
	{ 
		System.out.println("from constructor");
		this.a=a;
	}

	public static void main(String[] args) {
		   Test obj= new Test(10);
		   System.out.println(obj.a);
		   
		   Test obj2= new Test(20);
		   System.out.println(obj2.a);
		   

	}

}
