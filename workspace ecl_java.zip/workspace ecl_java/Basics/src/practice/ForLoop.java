package practice;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       for(int i=1,j=2,k=3;i<4;i++,j++,k++)
       {
    	   System.out.println("hi");
       }
	}

}
