package practice;

public class ArrayAdd {

	public static void main(String[] args) {
		int 
     int[] array = new int[5];
     
     for(int =1;i<=5;i++)
 
	}

}
