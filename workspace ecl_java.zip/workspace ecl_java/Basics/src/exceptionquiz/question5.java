package exceptionquiz;

public class question5 {

	public static void main(String[] args) {
	
	}
	