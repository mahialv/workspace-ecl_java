package classpractice;

import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		
		Scanner sc =new Scanner(System.in);
		Student student = new Student();
		
		System.out.println("\n enter the roll number");
		student.setRollNumber(sc.nextInt());
		
		System.out.println("\n enter name");
		student.setName(sc.next());
		
		System.out.println("\n enter the number of courses");
		int coursearraylength = sc.nextInt();
		
		System.out.println("\n enter the courses name");
		String[] coursearray= new String[coursearraylength];
		
		for(int i=0; i< coursearray.length; i++)
		{
			coursearray[i] = sc.next();
		}
		
		student.setCourseName(coursearray);
		
		System.out.println();
		
		System.out.println("\n roll number:" + student.getRollNumber());
		System.out.println("\n name:" + student.getName());
		System.out.println("\n course names:");
		
		for(int i=0; i< student.getCourseName().length; i++)
		{
			System.out.println(student.getCourseName() [i]);
		}	
		
	}

}
