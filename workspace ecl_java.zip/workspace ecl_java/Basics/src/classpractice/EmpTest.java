package classpractice;

public class EmpTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Employee e = new Employee();
       System.out.println();
	}

}
