package classpractice;

import java.util.Scanner;

public class CommandExample {
Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
System.out.println("sum "+(num1+num2));
	}

}
