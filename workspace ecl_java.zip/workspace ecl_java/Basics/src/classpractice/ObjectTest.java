package classpractice;

import java.util.Scanner;

public class ObjectTest {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 ObjectEmployee [] employee = new ObjectEmployee[3];
		 
		 for(int i=0; i<employee.length; i++)
		 {
			 employee[i]= new ObjectEmployee();
			 System.out.println("\n enter name");
			 employee[i].setName(sc.next());
		 }

		 System.out.println();
		 for(int i=0;i<employee.length;i++)
{
	System.out.println(employee[i].getName());
}
		 
	}   

}
