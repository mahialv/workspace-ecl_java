package classpractice;

class SuperClass {

	SuperClass(){
		
		System.out.println("calling parent");
	}
}
	 class ChildClass extends SuperClass{
	 ChildClass(){
		 super();
		 System.out.println("child created");
	 }
	
public static void main(String[] args) {

	}

}
