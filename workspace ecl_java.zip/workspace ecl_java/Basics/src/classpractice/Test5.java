package classpractice;

public class Test5 {

	public static void main(String[] args) {
		Integer i = new Integer(5);
		Integer j= 5;
		System.out.println(i==j);
}
}



