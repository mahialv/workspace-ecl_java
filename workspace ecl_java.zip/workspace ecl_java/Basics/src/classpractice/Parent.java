package classpractice;

public class Parent {
    
    Parent(int a)
    {
    System.out.println("parent constructor");
    a=10;
    }
    
    class Child extends Parent
    {
    	int b;
    	Child()
    	{
    		System.out.println("child constructor");
    	    b=20;
    	}
    	
    }
    
    
}
    
