package classpractice;

public class Test4 {

	public static void main(String[] args) {
		
	}

}
