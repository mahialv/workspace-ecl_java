package classpractice;

public class Student {
  int rollNumber;
  String name;
  String [] courseName;
public String[] getCourseName() {
	return courseName;
}
public void setCourseName(String[] courseName) {
	this.courseName = courseName;
}
public int getRollNumber() {
	return rollNumber;
}
public void setRollNumber(int rollNumber) {
	this.rollNumber = rollNumber;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
