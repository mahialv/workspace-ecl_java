package classpractice;

public @interface override {

}
