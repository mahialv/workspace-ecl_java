package classpractice;

public class Test3 {
	
	Test3()
	{
		System.out.println("constructor");

	}
	{
		System.out.println("instance block");
		
	}
	{
		System.out.println("instance block2");
	}
static
{
	System.out.println("startic block");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 Test3 obj = new Test3();
 Test3 obj2 = new Test3();
	}

}
