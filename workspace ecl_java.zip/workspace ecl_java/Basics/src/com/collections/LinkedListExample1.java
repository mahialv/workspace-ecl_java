package com.collections;

import java.util.ListIterator;
import java.util.LinkedList;

public class LinkedListExample1 {

	public static void main(String[] args) {
		
		
		LinkedList<String> l = new LinkedList<String>();
		
		l.add("3");
		l.add("7");
		l.add("9");
		
		l.add("mahesh");
		l.add("nithya");	
		 ListIterator<String> itr = l.listIterator(l.size());

		  System.out.println("Size of Elements:" +size());
		   while (itr.hasNext())
		   {
		   System.out.println(itr.next());
		 
		   }

	}


	}


