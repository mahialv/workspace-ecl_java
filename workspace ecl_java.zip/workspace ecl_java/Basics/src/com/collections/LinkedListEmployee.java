package com.collections;

public class LinkedListEmployee {

	public static void main(String[] args) {
	

	}

}
