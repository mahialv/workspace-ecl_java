package com.collections;

import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;


public class MapExmaple {

	public static void main(String[] args) {
		
  HashMap<Integer,String> map = new HashMap<Integer,String>();
  
  map.put(2,  "two");
  map.put(3, "two");
  
  System.out.println(map);
  Set set = map.keySet();
  
  Iterator it = set.iterator();
  
  while(it.hasNext())
  {
	  Integer key = (Integer)it.next();
	  
  }
  /*
  System.out.println("using entryset");
  Set set2 = map.entrySet();
  Iterator it2 = set2.iterator();
  while(it2.hasNext())
  {
	  Map.Entry me= (Map.Entry)it2.next();
	  Integer key =(Integer)me.getKey();
	  System.out.println(key);
	  System.out.println(map.get(key));
	  
	  
  }*/
  
	}

}
