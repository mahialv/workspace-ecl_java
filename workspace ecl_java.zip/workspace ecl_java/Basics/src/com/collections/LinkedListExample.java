package com.collections;

import java.util.LinkedList;
import java.util.ListIterator;

import java.util.Iterator;

public class LinkedListExample {

	public static void main(String[] args) {
		 LinkedList<Integer>l =new LinkedList<Integer>();
		 
		 l.add(2);// autoboxing happening
		 
		 l.add(4);
		 l.add(4);
		 l.add(null);
		 // 1 using object
		 System.out.println(l);// toString of linked List
		 
		 
		 // 2 using index
		 for(int i=0;i<l.size();i++)
		 {
			 System.out.println(l.get(i));
		 }
		 
		 //3 using for each loop
		 for(Integer obj: l)
		 {
			 System.out.println(obj);
		 }
	
		 // 4 using iterator
		 Iterator<Integer> it = l.iterator();
		 
		 while(it.hasNext())
		 {
			 System.out.println(it.next());
		 }
		 
		 // using list iterator
		 ListIterator<Integer> listit = l.listIterator();
		 
		 while(listit.hasNext())
		 {
			 System.out.println(listit.next());
		 }
	}

}
