package exceptionhandling;

public class InsufficentBalance extends Exception {
	
	public InsufficentBalance(){
		
		getMessage();
	}ssss
	
	@Override
	public String getMessage(){
		
		return "javalang.BalanceException";
	
	}

}
