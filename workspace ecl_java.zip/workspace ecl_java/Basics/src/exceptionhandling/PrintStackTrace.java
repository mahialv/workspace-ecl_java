package exceptionhandling;

public class PrintStackTrace {

	public static void main(String[] args) {
		
		try
		 {
			 m1();
		 }
		 catch(ArithmeticException ae)
		 {
			 System.out.println("zero division error");
		 }
	
	}

	private static void m1() {
		m2();
	}

	private static void m2() {
		m3();
	}

	private static void m3() {
					
			 int a=100;
			 int b=0;
			 int c= a/b;
			 System.out.println("Division:" +c);
		 }
		
	}


