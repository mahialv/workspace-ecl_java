package exceptionhandling;

public class Arithmetic extends Exception {

}
